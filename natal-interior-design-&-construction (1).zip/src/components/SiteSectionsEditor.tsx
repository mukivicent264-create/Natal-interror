import React, { useState, useRef } from 'react';
import { 
  Sparkles, CheckCircle, RotateCcw, Upload, Image as ImageIcon, 
  Layers, Compass, ShieldCheck, Clock, ThumbsUp, MapPin, Phone, 
  Mail, MessageSquare, AlertCircle, Eye, Save, HelpCircle,
  FileText, ExternalLink, ArrowRight, Video, Film, Play, Pause, Volume2, VolumeX,
  FolderArchive, Check, RefreshCw, SlidersHorizontal
} from 'lucide-react';
import {
  HeroContent, defaultHeroContent,
  AboutContent, defaultAboutContent,
  WhyUsContent, defaultWhyUsContent,
  ProcessContent, defaultProcessContent,
  StatsContent, defaultStatsContent,
  ContactContent, defaultContactContent,
  useSectionContent
} from '../siteContent';
import { compressImageFile, storeSafeMediaAssetInCloud, captureVideoThumbnail } from '../utils';

type SectionKey = 'hero' | 'about' | 'why_us' | 'process' | 'stats' | 'contact';

const SECTIONS: { id: SectionKey; label: string; icon: any; desc: string }[] = [
  { id: 'hero', label: 'Hero Section', icon: Sparkles, desc: 'Headlines, background visual, primary CTA, and quick showcase cards' },
  { id: 'about', label: 'About Atelier', icon: Compass, desc: 'Story narrative, atelier portrait, experience years, and core disciplines' },
  { id: 'why_us', label: 'Why Choose Us', icon: ShieldCheck, desc: 'Value propositions, performance metrics, and section backdrop' },
  { id: 'process', label: 'The Process', icon: Layers, desc: '5-step architectural execution journey and client deliverables' },
  { id: 'stats', label: 'Stats & Numbers', icon: Clock, desc: 'Live counters for completed projects, years of practice, and client satisfaction' },
  { id: 'contact', label: 'Studio & Contact', icon: MapPin, desc: 'Atelier location, phone numbers, WhatsApp, email, and social networks' },
];

export const SiteSectionsEditor: React.FC = () => {
  const [activeSection, setActiveSection] = useState<SectionKey>('hero');
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  const showNotification = (msg: string) => {
    setSuccessNotice(msg);
    setTimeout(() => setSuccessNotice(null), 4500);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="border-b border-gold/20 pb-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono text-gold uppercase tracking-widest block">Content Management System</span>
          <h2 className="text-xl sm:text-2xl font-heading text-white uppercase tracking-wider mt-0.5">
            Website Sections Editor
          </h2>
          <p className="text-xs text-gray-400 mt-1">
            Update copy, replace images, and configure content for each homepage section in real-time.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <a
            href="/"
            target="_blank"
            rel="noopener noreferrer"
            className="px-3.5 py-2 bg-black-pure border border-gold/40 text-gold hover:bg-gold/10 hover:border-gold transition-all text-xs font-mono uppercase tracking-wider flex items-center gap-1.5 cursor-pointer shadow-sm"
          >
            <Eye size={14} />
            <span>Preview Live Site</span>
            <ExternalLink size={12} className="opacity-70" />
          </a>
        </div>
      </div>

      {/* Success Notification */}
      {successNotice && (
        <div className="p-3.5 bg-emerald-950/40 border border-emerald-500/50 text-emerald-300 text-xs flex items-center justify-between shadow-lg animate-fadeIn">
          <div className="flex items-center gap-2.5">
            <CheckCircle size={16} className="text-emerald-400 shrink-0" />
            <span className="font-medium">{successNotice}</span>
          </div>
          <span className="text-[10px] font-mono uppercase text-emerald-400/80">Live Synced</span>
        </div>
      )}

      {/* Horizontal Section Selector Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
        {SECTIONS.map((sec) => {
          const Icon = sec.icon;
          const isActive = activeSection === sec.id;
          return (
            <button
              key={sec.id}
              onClick={() => setActiveSection(sec.id)}
              className={`p-3 text-left transition-all border flex flex-col justify-between cursor-pointer rounded-none relative group ${
                isActive
                  ? 'bg-gold/15 border-gold text-white shadow-[0_0_15px_rgba(212,175,55,0.2)]'
                  : 'bg-black-pure border-white/10 text-gray-400 hover:text-white hover:border-gold/40 hover:bg-white/5'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className={`w-7 h-7 flex items-center justify-center rounded-none border ${
                  isActive ? 'bg-gold text-black-pure border-gold' : 'bg-gold/10 text-gold border-gold/30'
                }`}>
                  <Icon size={14} />
                </div>
                {isActive && (
                  <span className="w-1.5 h-1.5 rounded-full bg-gold animate-pulse"></span>
                )}
              </div>
              <div>
                <span className={`text-xs font-bold font-heading block uppercase tracking-wider truncate ${
                  isActive ? 'text-gold' : 'text-white'
                }`}>
                  {sec.label}
                </span>
                <span className="text-[9px] text-gray-500 font-mono block truncate mt-0.5">
                  {sec.desc}
                </span>
              </div>
              {isActive && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gold"></div>
              )}
            </button>
          );
        })}
      </div>

      {/* Section Content Workspaces */}
      <div className="bg-black-pure border border-gold/30 p-4 sm:p-6 shadow-2xl">
        {activeSection === 'hero' && <HeroSectionEditor onNotify={showNotification} />}
        {activeSection === 'about' && <AboutSectionEditor onNotify={showNotification} />}
        {activeSection === 'why_us' && <WhyUsSectionEditor onNotify={showNotification} />}
        {activeSection === 'process' && <ProcessSectionEditor onNotify={showNotification} />}
        {activeSection === 'stats' && <StatsSectionEditor onNotify={showNotification} />}
        {activeSection === 'contact' && <ContactSectionEditor onNotify={showNotification} />}
      </div>
    </div>
  );
};

// ---------------------------------------------------------------------------
// Reusable Image File Uploader Component
// ---------------------------------------------------------------------------
interface ImageUploadFieldProps {
  label: string;
  helper?: string;
  value: string;
  onChange: (url: string) => void;
  maxWidth?: number;
  maxHeight?: number;
}

const ImageUploadField: React.FC<ImageUploadFieldProps> = ({ 
  label, 
  helper, 
  value, 
  onChange,
  maxWidth = 1920,
  maxHeight = 1080 
}) => {
  const [isUrlMode, setIsUrlMode] = useState(false);
  const [isCompressing, setIsCompressing] = useState(false);

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsCompressing(true);
    try {
      // Automatically compress and resize image for optimal quality & instant display
      const compressedBase64 = await compressImageFile(file, maxWidth, maxHeight, 0.82);
      onChange(compressedBase64);
    } catch (err) {
      console.error('Image compression error:', err);
      const reader = new FileReader();
      reader.onload = (ev) => {
        if (typeof ev.target?.result === 'string') {
          onChange(ev.target.result);
        }
      };
      reader.readAsDataURL(file);
    } finally {
      setIsCompressing(false);
    }
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <label className="text-xs font-semibold uppercase tracking-wider text-gray-200">
          {label}
        </label>
        <button
          type="button"
          onClick={() => setIsUrlMode(!isUrlMode)}
          className="text-[10px] font-mono text-gold hover:underline cursor-pointer"
        >
          {isUrlMode ? 'Switch to File Upload' : 'Paste Image URL instead'}
        </button>
      </div>

      {helper && <p className="text-[11px] text-gray-400">{helper}</p>}

      <div className="grid sm:grid-cols-12 gap-3 items-center">
        {/* Preview Container */}
        <div className="sm:col-span-4 aspect-video sm:aspect-square md:aspect-video bg-black-rich border border-gold/30 relative overflow-hidden flex items-center justify-center group">
          {isCompressing ? (
            <div className="text-center p-3 text-gold flex flex-col items-center justify-center">
              <span className="w-5 h-5 border-2 border-gold border-t-transparent rounded-full animate-spin mb-2" />
              <span className="text-[10px] font-mono">Compressing...</span>
            </div>
          ) : value ? (
            <>
              <img src={value} alt="Preview" className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center p-2 text-center">
                <span className="text-[10px] text-white font-mono">Live Display Image</span>
              </div>
            </>
          ) : (
            <div className="text-center p-3 text-gray-500">
              <ImageIcon size={24} className="mx-auto mb-1 opacity-50" />
              <span className="text-[10px] font-mono block">No image selected</span>
            </div>
          )}
        </div>

        {/* Input area */}
        <div className="sm:col-span-8 space-y-2">
          {isUrlMode ? (
            <input
              type="url"
              value={value}
              onChange={(e) => onChange(e.target.value)}
              placeholder="https://images.unsplash.com/... or cloud storage URL"
              className="w-full bg-black-rich border border-white/20 focus:border-gold px-3 py-2.5 text-xs text-white placeholder:text-gray-600 focus:outline-none font-mono"
            />
          ) : (
            <label className="w-full border border-dashed border-gold/40 hover:border-gold bg-black-rich/50 hover:bg-gold/5 p-4 flex flex-col items-center justify-center cursor-pointer transition-all">
              <Upload size={20} className="text-gold mb-1" />
              <span className="text-xs text-gray-200 font-medium">
                {isCompressing ? 'Compressing & uploading...' : 'Click to upload from device'}
              </span>
              <span className="text-[10px] text-gray-400 font-mono mt-0.5">
                Automatically compressed & resized for instant homepage loading
              </span>
              <input 
                type="file" 
                accept="image/*" 
                disabled={isCompressing} 
                onChange={handleFile} 
                className="hidden" 
              />
            </label>
          )}

          {value && (
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1">
                <CheckCircle size={11} className="text-emerald-400" />
                <span>Ready & optimized for display</span>
              </span>
              <button
                type="button"
                onClick={() => onChange('')}
                className="text-[10px] text-red-400 hover:text-red-300 font-mono flex items-center gap-1 cursor-pointer"
              >
                Clear Image
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const HERO_VIDEO_PRESETS = [
  {
    id: 'preset-1',
    name: 'Modern Open-Concept Penthouse',
    desc: 'Contemporary luxury living with floating ceilings & floor-to-ceiling glass',
    url: 'https://assets.mixkit.co/videos/preview/mixkit-modern-apartment-with-an-open-concept-design-41005-large.mp4',
    poster: 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&q=80&w=2560'
  },
  {
    id: 'preset-2',
    name: 'Luxury Residence & Golden Lighting',
    desc: 'Bespoke gypsum coffered ceilings, warm perimeter LEDs & gilded interior',
    url: 'https://assets.mixkit.co/videos/preview/mixkit-interior-of-a-luxurious-modern-house-42661-large.mp4',
    poster: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&q=80&w=2560'
  },
  {
    id: 'preset-3',
    name: 'Ambient Warm Living & Media Wall',
    desc: 'Architectural joinery, marble accents & recessed downlight detailing',
    url: 'https://assets.mixkit.co/videos/preview/mixkit-living-room-with-modern-interior-design-41003-large.mp4',
    poster: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=2560'
  },
  {
    id: 'preset-4',
    name: 'Contemporary Kitchen & Island Atelier',
    desc: 'Sleek luxury cabinetry, bar seating and precision architectural finish',
    url: 'https://assets.mixkit.co/videos/preview/mixkit-modern-kitchen-interior-with-island-and-stools-41004-large.mp4',
    poster: 'https://images.unsplash.com/photo-1600607686527-6fb886090705?auto=format&fit=crop&q=80&w=2560'
  }
];

// ---------------------------------------------------------------------------
// 1. HERO SECTION EDITOR
// ---------------------------------------------------------------------------
const HeroSectionEditor: React.FC<{ onNotify: (msg: string) => void }> = ({ onNotify }) => {
  const { content, updateContent, resetToDefault, isSaving } = useSectionContent<HeroContent>('hero', defaultHeroContent);
  const [formData, setFormData] = useState<HeroContent>(content);
  const [cardCompressingIdx, setCardCompressingIdx] = useState<number | null>(null);
  const [isVideoUploading, setIsVideoUploading] = useState(false);
  const [customVideoUrl, setCustomVideoUrl] = useState('');
  const [isPreviewPlaying, setIsPreviewPlaying] = useState(true);
  const [isPreviewMuted, setIsPreviewMuted] = useState(true);
  const previewVideoRef = useRef<HTMLVideoElement>(null);
  const videoFileInputRef = useRef<HTMLInputElement>(null);

  // Sync when hook loaded
  React.useEffect(() => {
    setFormData(content);
  }, [content]);

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    await updateContent(formData);
    onNotify('Hero section content, background media & headlines published to Homepage & all devices!');
  };

  const handleReset = async () => {
    if (confirm('Reset Hero Section to atelier default (including video)?')) {
      await resetToDefault();
      setFormData(defaultHeroContent);
      onNotify('Hero Section reset to original default.');
    }
  };

  // Instant Auto-Save for Background Image
  const handleBackgroundChange = async (url: string) => {
    const next = { ...formData, backgroundImage: url };
    setFormData(next);
    try {
      await updateContent(next);
      onNotify('Hero background image updated and published to Homepage!');
    } catch (err: any) {
      console.warn('Auto-save error:', err);
    }
  };

  // Toggle between Video and Image mode
  const handleMediaTypeToggle = async (mode: 'video' | 'image') => {
    const next: HeroContent = {
      ...formData,
      mediaType: mode,
      backgroundVideo: mode === 'video' ? (formData.backgroundVideo || defaultHeroContent.backgroundVideo) : formData.backgroundVideo
    };
    setFormData(next);
    try {
      await updateContent(next);
      onNotify(`Hero section switched to ${mode === 'video' ? 'Cinematic Video Loop' : 'Static Image'} mode!`);
    } catch (err: any) {
      console.warn('Media mode toggle error:', err);
    }
  };

  // Handle Video File Upload from device (laptop or phone)
  const handleVideoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsVideoUploading(true);
    try {
      // 1. Generate video thumbnail for poster fallback
      let thumb = '';
      try {
        thumb = await captureVideoThumbnail(file);
      } catch (e) {
        console.warn('Could not extract thumbnail, using existing poster:', e);
      }

      // 2. Safely store in cloud media vault (with Firestore chunks if large)
      const savedMedia = await storeSafeMediaAssetInCloud({
        file,
        name: file.name,
        category: 'Hero Background Video',
        uploadedBy: 'Administrator'
      });

      const videoUrl = savedMedia?.url || '';
      if (!videoUrl) {
        throw new Error('Video encoding failed.');
      }

      const next: HeroContent = {
        ...formData,
        backgroundVideo: videoUrl,
        mediaType: 'video',
        backgroundImage: thumb || formData.backgroundImage
      };

      setFormData(next);
      await updateContent(next);
      onNotify(`Hero video "${file.name}" uploaded and published live across all devices!`);
    } catch (err: any) {
      console.error('Hero video upload error:', err);
      alert('Error uploading video: ' + (err?.message || String(err)));
    } finally {
      setIsVideoUploading(false);
      if (videoFileInputRef.current) videoFileInputRef.current.value = '';
    }
  };

  // Handle Preset Video Selection
  const handleSelectPreset = async (presetUrl: string, presetPoster: string, presetName: string) => {
    const next: HeroContent = {
      ...formData,
      backgroundVideo: presetUrl,
      mediaType: 'video',
      backgroundImage: presetPoster || formData.backgroundImage
    };
    setFormData(next);
    try {
      await updateContent(next);
      onNotify(`Hero video set to "${presetName}" and published live to all devices!`);
    } catch (err: any) {
      alert('Error applying video preset: ' + err.message);
    }
  };

  // Handle Direct Custom Video URL
  const handleApplyCustomVideoUrl = async () => {
    if (!customVideoUrl.trim()) return;
    const url = customVideoUrl.trim();
    const next: HeroContent = {
      ...formData,
      backgroundVideo: url,
      mediaType: 'video'
    };
    setFormData(next);
    try {
      await updateContent(next);
      onNotify('Custom video URL applied and published live to all devices!');
      setCustomVideoUrl('');
    } catch (err: any) {
      alert('Error applying video URL: ' + err.message);
    }
  };

  // In-Editor Video Play/Pause toggle
  const togglePreviewPlay = () => {
    if (previewVideoRef.current) {
      if (isPreviewPlaying) {
        previewVideoRef.current.pause();
        setIsPreviewPlaying(false);
      } else {
        previewVideoRef.current.play().catch(() => {});
        setIsPreviewPlaying(true);
      }
    }
  };

  // In-Editor Video Mute toggle
  const togglePreviewMute = () => {
    if (previewVideoRef.current) {
      const nextMuted = !isPreviewMuted;
      previewVideoRef.current.muted = nextMuted;
      setIsPreviewMuted(nextMuted);
    }
  };

  const updateCard = (index: number, key: 'img' | 'label', val: string) => {
    const nextCards = [...formData.cards];
    nextCards[index] = { ...nextCards[index], [key]: val };
    const next = { ...formData, cards: nextCards };
    setFormData(next);
    return next;
  };

  const handleCardFileUpload = async (idx: number, file: File) => {
    setCardCompressingIdx(idx);
    try {
      // Compress card image for fast loading and Firestore limit safety
      const compressed = await compressImageFile(file, 960, 640, 0.82);
      const nextCards = [...formData.cards];
      nextCards[idx] = { ...nextCards[idx], img: compressed };
      const next = { ...formData, cards: nextCards };
      setFormData(next);
      await updateContent(next);
      onNotify(`Hero Inspiration Card #${idx + 1} uploaded, compressed, and published to Homepage!`);
    } catch (err) {
      console.error('Card image compression error:', err);
      alert('Could not process this image file. Please try another image.');
    } finally {
      setCardCompressingIdx(null);
    }
  };

  const handleCardClear = async (idx: number) => {
    const nextCards = [...formData.cards];
    nextCards[idx] = { ...nextCards[idx], img: '' };
    const next = { ...formData, cards: nextCards };
    setFormData(next);
    try {
      await updateContent(next);
      onNotify(`Hero Inspiration Card #${idx + 1} image removed.`);
    } catch {}
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="flex items-center justify-between border-b border-gold/20 pb-3">
        <div>
          <h3 className="text-base font-heading font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Sparkles size={16} className="text-gold" />
            Hero Section Settings
          </h3>
          <p className="text-xs text-gray-400">First impression headline, background photograph, and action buttons</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleReset}
            className="text-xs font-mono text-gray-400 hover:text-gold flex items-center gap-1 cursor-pointer px-2.5 py-1.5 border border-white/10 hover:border-gold/30"
          >
            <RotateCcw size={13} /> Reset Default
          </button>
          <button
            type="submit"
            disabled={isSaving}
            className="px-4 py-1.5 bg-gradient-to-r from-gold-dark via-gold to-gold-light hover:brightness-110 text-black-pure font-bold transition-all text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-sm cursor-pointer disabled:opacity-50"
          >
            <Save size={13} />
            <span>{isSaving ? 'Saving...' : 'Save All Changes'}</span>
          </button>
        </div>
      </div>

      {/* Main 3-line Headline */}
      <div className="grid sm:grid-cols-3 gap-3">
        <div>
          <label className="block text-[11px] uppercase tracking-wider text-gray-300 font-semibold mb-1">
            Headline Line 1
          </label>
          <input
            type="text"
            value={formData.headline1}
            onChange={(e) => setFormData({ ...formData, headline1: e.target.value })}
            placeholder="WE DESIGN."
            className="w-full bg-black-rich border border-white/20 focus:border-gold px-3.5 py-2.5 text-xs text-white focus:outline-none"
            required
          />
        </div>
        <div>
          <label className="block text-[11px] uppercase tracking-wider text-gray-300 font-semibold mb-1">
            Headline Line 2
          </label>
          <input
            type="text"
            value={formData.headline2}
            onChange={(e) => setFormData({ ...formData, headline2: e.target.value })}
            placeholder="WE BUILD."
            className="w-full bg-black-rich border border-white/20 focus:border-gold px-3.5 py-2.5 text-xs text-white focus:outline-none"
            required
          />
        </div>
        <div>
          <label className="block text-[11px] uppercase tracking-wider text-gold font-semibold mb-1">
            Headline Line 3 (Gold Accent)
          </label>
          <input
            type="text"
            value={formData.headline3}
            onChange={(e) => setFormData({ ...formData, headline3: e.target.value })}
            placeholder="YOU ENJOY."
            className="w-full bg-black-rich border border-gold/50 focus:border-gold px-3.5 py-2.5 text-xs text-gold focus:outline-none font-semibold"
            required
          />
        </div>
      </div>

      {/* Description Paragraph */}
      <div>
        <label className="block text-[11px] uppercase tracking-wider text-gray-300 font-semibold mb-1">
          Hero Description Paragraph
        </label>
        <textarea
          rows={3}
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          placeholder="Summary of architectural solutions and interior excellence..."
          className="w-full bg-black-rich border border-white/20 focus:border-gold p-3.5 text-xs text-white focus:outline-none resize-none leading-relaxed"
          required
        />
      </div>

      {/* Hero Background Visual Media Manager (Video vs Image) */}
      <div className="bg-black-rich/60 p-4 sm:p-5 border border-gold/35 space-y-4 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-gold/20 pb-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono text-gold uppercase tracking-wider font-bold flex items-center gap-1.5">
                <Film size={14} className="text-gold" />
                Hero Background Visual Media
              </span>
              <span className="text-[9px] font-mono text-emerald-400 bg-emerald-950/70 border border-emerald-500/40 px-2 py-0.5">
                Live Cloud Sync • Laptop & Real Phone
              </span>
            </div>
            <p className="text-[11px] text-gray-400 mt-0.5">
              Choose between an atmospheric cinematic architectural video loop or an ultra-sharp static photograph.
            </p>
          </div>

          {/* Mode Switcher Buttons */}
          <div className="flex items-center p-1 bg-black-pure border border-gold/40 rounded-none shrink-0">
            <button
              type="button"
              onClick={() => handleMediaTypeToggle('video')}
              className={`px-3 py-1.5 text-xs font-mono font-bold uppercase tracking-wider transition-all flex items-center gap-1.5 cursor-pointer ${
                formData.mediaType !== 'image'
                  ? 'bg-gold text-black-pure shadow-[0_0_12px_rgba(212,175,55,0.4)]'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <Video size={13} />
              <span>Cinematic Video Loop</span>
              {formData.mediaType !== 'image' && (
                <span className="w-1.5 h-1.5 rounded-full bg-black-pure animate-pulse"></span>
              )}
            </button>
            <button
              type="button"
              onClick={() => handleMediaTypeToggle('image')}
              className={`px-3 py-1.5 text-xs font-mono font-bold uppercase tracking-wider transition-all flex items-center gap-1.5 cursor-pointer ${
                formData.mediaType === 'image'
                  ? 'bg-gold text-black-pure shadow-[0_0_12px_rgba(212,175,55,0.4)]'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <ImageIcon size={13} />
              <span>Static Photograph</span>
            </button>
          </div>
        </div>

        {/* -------------------- VIDEO MODE SECTION -------------------- */}
        {formData.mediaType !== 'image' ? (
          <div className="space-y-4">
            {/* Live Video Preview Box */}
            <div className="bg-black-pure border border-gold/30 p-3 sm:p-4 rounded-none relative overflow-hidden">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-mono uppercase tracking-widest text-gold flex items-center gap-1.5">
                  <Play size={11} className="fill-gold" />
                  Live Background Video Preview (Playing Live on Homepage)
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={togglePreviewPlay}
                    className="p-1 bg-white/5 hover:bg-gold hover:text-black-pure text-gray-300 transition-colors text-[10px] font-mono flex items-center gap-1 px-2 border border-white/10"
                    title={isPreviewPlaying ? 'Pause Preview' : 'Play Preview'}
                  >
                    {isPreviewPlaying ? <Pause size={12} /> : <Play size={12} className="fill-current" />}
                    <span>{isPreviewPlaying ? 'Pause' : 'Play'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={togglePreviewMute}
                    className="p-1 bg-white/5 hover:bg-gold hover:text-black-pure text-gray-300 transition-colors text-[10px] font-mono flex items-center gap-1 px-2 border border-white/10"
                    title={isPreviewMuted ? 'Unmute Audio' : 'Mute Audio'}
                  >
                    {isPreviewMuted ? <VolumeX size={12} /> : <Volume2 size={12} />}
                    <span>{isPreviewMuted ? 'Muted' : 'Sound On'}</span>
                  </button>
                </div>
              </div>

              {/* Video Player Display */}
              <div className="aspect-video w-full max-h-[300px] bg-black-rich border border-gold/20 relative overflow-hidden flex items-center justify-center">
                {formData.backgroundVideo ? (
                  <video
                    key={formData.backgroundVideo}
                    ref={previewVideoRef}
                    src={formData.backgroundVideo}
                    autoPlay
                    loop
                    muted={isPreviewMuted}
                    playsInline
                    poster={formData.backgroundImage}
                    className="w-full h-full object-cover"
                  >
                    <source src={formData.backgroundVideo} type="video/mp4" />
                    <source src={formData.backgroundVideo} type="video/webm" />
                  </video>
                ) : (
                  <div className="text-center p-6 text-gray-500">
                    <Video size={36} className="mx-auto mb-2 opacity-40 text-gold" />
                    <p className="text-xs font-mono text-gray-400">No background video assigned</p>
                  </div>
                )}

                {/* Scrim Overlay indicator */}
                <div className="absolute bottom-2 left-2 z-10 bg-black-pure/90 border border-gold/40 px-2.5 py-1 text-[9px] font-mono text-gold flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  <span className="truncate max-w-[280px]">
                    Source: {formData.backgroundVideo?.startsWith('data:') ? 'Device Upload (Encoded in Cloud)' : formData.backgroundVideo ? formData.backgroundVideo.slice(0, 45) + '...' : 'Default Loop'}
                  </span>
                </div>
              </div>
            </div>

            {/* Direct Upload From Device */}
            <div className="bg-black-pure/80 border border-gold/30 p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider font-heading flex items-center gap-1.5">
                    <Upload size={14} className="text-gold" />
                    Upload Video File from your Laptop or Phone
                  </h4>
                  <p className="text-[11px] text-gray-400 mt-0.5">
                    Select an MP4, WebM, or QuickTime MOV walkthrough video from your device. It will automatically encode, generate mobile poster frames, and stream across both laptops and real phones.
                  </p>
                </div>
              </div>

              {/* Upload Dropzone */}
              <label className="border-2 border-dashed border-gold/50 hover:border-gold bg-black-rich/60 hover:bg-gold/5 p-6 flex flex-col items-center justify-center cursor-pointer transition-all group">
                {isVideoUploading ? (
                  <div className="flex flex-col items-center justify-center p-3 text-gold">
                    <div className="w-8 h-8 border-2 border-gold border-t-transparent rounded-full animate-spin mb-3"></div>
                    <span className="text-xs font-mono font-bold uppercase tracking-wider">Uploading Video & Syncing to Cloud Database...</span>
                    <span className="text-[10px] text-gray-400 font-mono mt-1">Generating mobile poster & chunked cloud storage</span>
                  </div>
                ) : (
                  <>
                    <div className="w-12 h-12 rounded-full bg-gold/10 border border-gold/40 group-hover:scale-110 group-hover:bg-gold/20 transition-all flex items-center justify-center mb-2">
                      <Film size={22} className="text-gold" />
                    </div>
                    <span className="text-xs text-white font-bold tracking-wide">
                      Click to Browse or Drag & Drop Video File
                    </span>
                    <span className="text-[10px] text-gray-400 font-mono mt-1">
                      Supports MP4, WebM, MOV • Recommended 1080p landscape loop
                    </span>
                  </>
                )}
                <input
                  ref={videoFileInputRef}
                  type="file"
                  accept="video/mp4,video/webm,video/quicktime,video/*"
                  disabled={isVideoUploading}
                  onChange={handleVideoUpload}
                  className="hidden"
                />
              </label>
            </div>

            {/* Curated 1-Click Luxury Architectural Video Presets */}
            <div className="bg-black-pure/80 border border-gold/30 p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider font-heading flex items-center gap-1.5">
                    <Sparkles size={14} className="text-gold" />
                    Curated Luxury Interior Video Loops (1-Click Switch)
                  </h4>
                  <p className="text-[11px] text-gray-400 mt-0.5">
                    Instant high-definition architectural interior loops royalty-free and ready for production:
                  </p>
                </div>
              </div>

              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {HERO_VIDEO_PRESETS.map((preset) => {
                  const isCurrent = formData.backgroundVideo === preset.url;
                  return (
                    <div
                      key={preset.id}
                      className={`border p-3 flex flex-col justify-between transition-all relative ${
                        isCurrent
                          ? 'bg-gold/15 border-gold shadow-[0_0_15px_rgba(212,175,55,0.3)]'
                          : 'bg-black-rich border-white/10 hover:border-gold/50'
                      }`}
                    >
                      <div className="aspect-video w-full mb-2 overflow-hidden bg-black-pure relative">
                        <img
                          src={preset.poster}
                          alt={preset.name}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                          <Play size={18} className="text-white fill-white opacity-80" />
                        </div>
                        {isCurrent && (
                          <div className="absolute top-1 right-1 bg-gold text-black-pure text-[8px] font-mono font-bold px-1.5 py-0.5 uppercase tracking-wider flex items-center gap-1">
                            <Check size={9} /> Active
                          </div>
                        )}
                      </div>

                      <div className="space-y-1 mb-2.5">
                        <h5 className="text-xs font-bold text-white line-clamp-1">{preset.name}</h5>
                        <p className="text-[10px] text-gray-400 line-clamp-2 leading-relaxed">{preset.desc}</p>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleSelectPreset(preset.url, preset.poster, preset.name)}
                        disabled={isCurrent}
                        className={`w-full py-1.5 text-[10px] font-mono uppercase tracking-wider font-bold transition-all cursor-pointer ${
                          isCurrent
                            ? 'bg-emerald-900/60 text-emerald-300 border border-emerald-500/50 cursor-default'
                            : 'bg-black-pure hover:bg-gold text-gold hover:text-black-pure border border-gold/40 hover:border-gold'
                        }`}
                      >
                        {isCurrent ? 'Active On Homepage' : 'Use This Video'}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Direct Video URL Input */}
            <div className="bg-black-pure/80 border border-gold/30 p-4 space-y-2">
              <label className="block text-xs font-bold uppercase tracking-wider text-gray-300 font-heading">
                Or Paste Direct Video URL (AWS S3, Cloudinary, CDN)
              </label>
              <div className="flex gap-2">
                <input
                  type="url"
                  value={customVideoUrl}
                  onChange={(e) => setCustomVideoUrl(e.target.value)}
                  placeholder="https://your-domain.com/video.mp4 or CDN link"
                  className="flex-1 bg-black-rich border border-white/20 focus:border-gold px-3 py-2 text-xs text-white placeholder:text-gray-600 focus:outline-none font-mono"
                />
                <button
                  type="button"
                  onClick={handleApplyCustomVideoUrl}
                  disabled={!customVideoUrl.trim()}
                  className="px-4 py-2 bg-gold hover:bg-gold-light active:bg-gold-dark disabled:opacity-40 text-black-pure font-bold font-mono text-xs uppercase tracking-wider transition-all cursor-pointer shrink-0"
                >
                  Apply Video URL
                </button>
              </div>
            </div>

            {/* Fallback Poster Image for Mobile & Low-Power Mode */}
            <div className="bg-black-pure/80 border border-gold/30 p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-gold font-heading flex items-center gap-1.5">
                  <ImageIcon size={14} className="text-gold" />
                  Mobile & Low-Power Video Poster Fallback
                </span>
                <span className="text-[10px] font-mono text-gray-400">
                  Displayed while video streams or on mobile low power mode
                </span>
              </div>
              <ImageUploadField
                label="Fallback Poster Image"
                helper="High-resolution photograph shown before video plays or if video playback is restricted by mobile data saver."
                value={formData.backgroundImage}
                maxWidth={1920}
                maxHeight={1080}
                onChange={handleBackgroundChange}
              />
            </div>
          </div>
        ) : (
          /* -------------------- IMAGE MODE SECTION -------------------- */
          <div className="space-y-2">
            <ImageUploadField
              label="Hero Main Background Photograph"
              helper="High-resolution architectural photograph for the hero backdrop. It will be compressed to optimal web resolution and published immediately to the Homepage across all devices."
              value={formData.backgroundImage}
              maxWidth={1920}
              maxHeight={1080}
              onChange={handleBackgroundChange}
            />
          </div>
        )}
      </div>

      {/* Button Labels */}
      <div className="grid sm:grid-cols-2 gap-4 pt-2 border-t border-white/10">
        <div>
          <label className="block text-[11px] uppercase tracking-wider text-gray-300 font-semibold mb-1">
            Primary Button Label (Gold)
          </label>
          <input
            type="text"
            value={formData.primaryCtaText}
            onChange={(e) => setFormData({ ...formData, primaryCtaText: e.target.value })}
            placeholder="Request Quotation"
            className="w-full bg-black-rich border border-white/20 focus:border-gold px-3.5 py-2.5 text-xs text-white focus:outline-none"
          />
        </div>
        <div>
          <label className="block text-[11px] uppercase tracking-wider text-gray-300 font-semibold mb-1">
            Secondary Button Label (Outline)
          </label>
          <input
            type="text"
            value={formData.secondaryCtaText}
            onChange={(e) => setFormData({ ...formData, secondaryCtaText: e.target.value })}
            placeholder="Explore Showcase"
            className="w-full bg-black-rich border border-white/20 focus:border-gold px-3.5 py-2.5 text-xs text-white focus:outline-none"
          />
        </div>
      </div>

      {/* 4 Quick Inspiration Cards at the Bottom of Hero Section */}
      <div className="pt-4 border-t border-white/10 space-y-4">
        <div>
          <div className="flex items-center justify-between">
            <label className="block text-xs uppercase tracking-wider text-gold font-bold flex items-center gap-2">
              <ImageIcon size={15} className="text-gold" />
              <span>Hero Bottom Inspiration Gallery Cards (4 Columns)</span>
            </label>
            <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 border border-emerald-500/30">
              Live Homepage Grid • Auto-Syncs on Upload
            </span>
          </div>
          <p className="text-[11px] text-gray-400 mt-1">
            These are the 4 showcase cards displayed at the bottom of the hero section. Uploading a photo will automatically compress it and publish it straight to the Homepage.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {formData.cards.map((card, idx) => (
            <div key={idx} className="bg-black-rich border border-gold/30 hover:border-gold/60 transition-colors p-3.5 space-y-3 relative group">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-mono font-bold text-gold uppercase tracking-wider flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-gold"></span>
                  Card #{idx + 1}
                </span>
                {card.img && (
                  <button
                    type="button"
                    onClick={() => handleCardClear(idx)}
                    className="text-[10px] text-red-400 hover:text-red-300 font-mono transition-colors cursor-pointer"
                    title="Remove image"
                  >
                    Clear Image
                  </button>
                )}
              </div>

              <div>
                <label className="block text-[10px] font-mono uppercase text-gray-400 mb-1">
                  Card Label / Category
                </label>
                <input
                  type="text"
                  value={card.label}
                  onChange={(e) => updateCard(idx, 'label', e.target.value)}
                  placeholder="e.g. Gypsum Ceilings"
                  className="w-full bg-black-pure border border-white/20 focus:border-gold px-2.5 py-1.5 text-xs text-white focus:outline-none"
                  required
                />
              </div>

              {/* Image Preview Box */}
              <div className="relative aspect-[16/10] bg-black-pure border border-gold/20 overflow-hidden flex items-center justify-center">
                {cardCompressingIdx === idx ? (
                  <div className="text-center p-3 text-gold flex flex-col items-center justify-center">
                    <span className="w-5 h-5 border-2 border-gold border-t-transparent rounded-full animate-spin mb-1.5" />
                    <span className="text-[10px] font-mono">Compressing & Saving...</span>
                  </div>
                ) : card.img ? (
                  <>
                    <img 
                      src={card.img} 
                      alt={card.label || `Card ${idx + 1}`} 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" 
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black-pure/80 via-transparent to-transparent opacity-80" />
                    <span className="absolute bottom-1.5 left-2 text-[10px] font-mono text-gold font-medium truncate max-w-[90%]">
                      {card.label}
                    </span>
                  </>
                ) : (
                  <div className="text-center p-3 text-gray-500 flex flex-col items-center justify-center">
                    <ImageIcon size={20} className="mb-1 opacity-40 text-gold" />
                    <span className="text-[10px] font-mono text-gray-400">No Image Uploaded</span>
                  </div>
                )}
              </div>

              {/* Upload Buttons: Device Upload & URL */}
              <div className="space-y-1.5 pt-1">
                <label className="w-full bg-gold/10 hover:bg-gold/20 border border-gold/40 text-gold py-1.5 px-2 flex items-center justify-center gap-1.5 text-[11px] font-mono uppercase tracking-wider cursor-pointer transition-colors text-center">
                  <Upload size={12} className="text-gold" />
                  <span>{cardCompressingIdx === idx ? 'Processing...' : 'Upload from Device'}</span>
                  <input
                    type="file"
                    accept="image/*"
                    disabled={cardCompressingIdx === idx}
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (!file) return;
                      handleCardFileUpload(idx, file);
                    }}
                    className="hidden"
                  />
                </label>

                <div className="flex items-center gap-1">
                  <input
                    type="url"
                    value={card.img}
                    onChange={(e) => updateCard(idx, 'img', e.target.value)}
                    placeholder="Or paste image URL..."
                    className="w-full bg-black-pure border border-white/20 focus:border-gold px-2 py-1 text-[10px] text-gray-300 focus:outline-none font-mono placeholder:text-gray-600"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="pt-4 border-t border-gold/20 flex items-center justify-between gap-3">
        <span className="text-[11px] font-mono text-gray-400 flex items-center gap-1.5">
          <CheckCircle size={13} className="text-emerald-400" />
          <span>Photos auto-save immediately; text updates save on click</span>
        </span>
        <button
          type="submit"
          disabled={isSaving}
          className="px-6 py-3 bg-gradient-to-r from-gold-dark via-gold to-gold-light hover:brightness-110 text-black-pure font-bold transition-all text-xs uppercase tracking-widest flex items-center gap-2 shadow-[0_2px_15px_rgba(212,175,55,0.35)] cursor-pointer active:scale-95 disabled:opacity-50"
        >
          <Save size={15} />
          <span>{isSaving ? 'Saving...' : 'Save All Changes'}</span>
        </button>
      </div>
    </form>
  );
};

// ---------------------------------------------------------------------------
// 2. ABOUT SECTION EDITOR
// ---------------------------------------------------------------------------
const AboutSectionEditor: React.FC<{ onNotify: (msg: string) => void }> = ({ onNotify }) => {
  const { content, updateContent, resetToDefault, isSaving } = useSectionContent<AboutContent>('about', defaultAboutContent);
  const [formData, setFormData] = useState<AboutContent>(content);

  React.useEffect(() => {
    setFormData(content);
  }, [content]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateContent(formData);
    onNotify('About section content & atelier photo updated successfully!');
  };

  const handleReset = async () => {
    if (confirm('Reset About Section to atelier default?')) {
      await resetToDefault();
      setFormData(defaultAboutContent);
      onNotify('About Section reset to original default.');
    }
  };

  const updatePillar = (idx: number, key: 'title' | 'subtitle', val: string) => {
    const next = [...formData.pillars];
    next[idx] = { ...next[idx], [key]: val };
    setFormData({ ...formData, pillars: next });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="flex items-center justify-between border-b border-gold/20 pb-3">
        <div>
          <h3 className="text-base font-heading font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Compass size={16} className="text-gold" />
            About Atelier Section
          </h3>
          <p className="text-xs text-gray-400">Company background, heritage, craftsmanship story, and focus disciplines</p>
        </div>
        <button
          type="button"
          onClick={handleReset}
          className="text-xs font-mono text-gray-400 hover:text-gold flex items-center gap-1 cursor-pointer"
        >
          <RotateCcw size={13} /> Reset Default
        </button>
      </div>

      <div className="grid sm:grid-cols-3 gap-3">
        <div>
          <label className="block text-[11px] uppercase tracking-wider text-gold font-semibold mb-1">
            Eyebrow Tagline
          </label>
          <input
            type="text"
            value={formData.subtitle}
            onChange={(e) => setFormData({ ...formData, subtitle: e.target.value })}
            placeholder="About Natal"
            className="w-full bg-black-rich border border-gold/40 focus:border-gold px-3.5 py-2.5 text-xs text-white focus:outline-none"
            required
          />
        </div>
        <div>
          <label className="block text-[11px] uppercase tracking-wider text-gray-300 font-semibold mb-1">
            Heading Line 1
          </label>
          <input
            type="text"
            value={formData.titleLine1}
            onChange={(e) => setFormData({ ...formData, titleLine1: e.target.value })}
            placeholder="Architectural Elegance,"
            className="w-full bg-black-rich border border-white/20 focus:border-gold px-3.5 py-2.5 text-xs text-white focus:outline-none"
            required
          />
        </div>
        <div>
          <label className="block text-[11px] uppercase tracking-wider text-gold font-semibold mb-1">
            Heading Line 2 (Accent)
          </label>
          <input
            type="text"
            value={formData.titleLine2}
            onChange={(e) => setFormData({ ...formData, titleLine2: e.target.value })}
            placeholder="Delivered With Precision."
            className="w-full bg-black-rich border border-gold/50 focus:border-gold px-3.5 py-2.5 text-xs text-gold focus:outline-none font-semibold"
            required
          />
        </div>
      </div>

      {/* Narrative Story */}
      <div>
        <label className="block text-[11px] uppercase tracking-wider text-gray-300 font-semibold mb-1">
          Narrative Story
        </label>
        <textarea
          rows={3}
          value={formData.narrative}
          onChange={(e) => setFormData({ ...formData, narrative: e.target.value })}
          placeholder="Atelier history, mastery, and dedication to excellence..."
          className="w-full bg-black-rich border border-white/20 focus:border-gold p-3.5 text-xs text-white focus:outline-none resize-none leading-relaxed"
          required
        />
      </div>

      {/* Experience Badge Numbers */}
      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-[11px] uppercase tracking-wider text-gray-300 font-semibold mb-1">
            Experience Number
          </label>
          <input
            type="text"
            value={formData.experienceYears}
            onChange={(e) => setFormData({ ...formData, experienceYears: e.target.value })}
            placeholder="20+"
            className="w-full bg-black-rich border border-white/20 focus:border-gold px-3.5 py-2.5 text-xs text-white focus:outline-none font-mono"
          />
        </div>
        <div>
          <label className="block text-[11px] uppercase tracking-wider text-gray-300 font-semibold mb-1">
            Experience Label Text
          </label>
          <input
            type="text"
            value={formData.experienceLabel}
            onChange={(e) => setFormData({ ...formData, experienceLabel: e.target.value })}
            placeholder="Years of Architectural Mastery"
            className="w-full bg-black-rich border border-white/20 focus:border-gold px-3.5 py-2.5 text-xs text-white focus:outline-none"
          />
        </div>
      </div>

      {/* Atelier Image */}
      <ImageUploadField
        label="About Atelier Image"
        helper="Primary showcase photograph of the atelier's craftsmanship or completed interior work."
        value={formData.image}
        onChange={(val) => setFormData({ ...formData, image: val })}
      />

      {/* 4 Core Pillars */}
      <div className="pt-2 border-t border-white/10 space-y-3">
        <label className="block text-xs uppercase tracking-wider text-gray-200 font-semibold">
          4 Focus Pillars
        </label>
        <div className="grid sm:grid-cols-2 gap-3">
          {formData.pillars.map((pillar, idx) => (
            <div key={idx} className="bg-black-rich border border-white/10 p-3 space-y-2">
              <span className="text-[10px] font-mono text-gold uppercase block">Pillar #{idx + 1}</span>
              <input
                type="text"
                value={pillar.title}
                onChange={(e) => updatePillar(idx, 'title', e.target.value)}
                placeholder="Pillar Title"
                className="w-full bg-black-pure border border-white/20 focus:border-gold px-3 py-2 text-xs text-white focus:outline-none"
              />
              <input
                type="text"
                value={pillar.subtitle}
                onChange={(e) => updatePillar(idx, 'subtitle', e.target.value)}
                placeholder="Pillar Subtitle / Description"
                className="w-full bg-black-pure border border-white/20 focus:border-gold px-3 py-1.5 text-[11px] text-gray-400 focus:outline-none"
              />
            </div>
          ))}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="pt-4 border-t border-gold/20 flex justify-end gap-3">
        <button
          type="submit"
          disabled={isSaving}
          className="px-6 py-3 bg-gradient-to-r from-gold-dark via-gold to-gold-light hover:brightness-110 text-black-pure font-bold transition-all text-xs uppercase tracking-widest flex items-center gap-2 shadow-[0_2px_15px_rgba(212,175,55,0.35)] cursor-pointer active:scale-95 disabled:opacity-50"
        >
          <Save size={15} />
          <span>{isSaving ? 'Saving...' : 'Save About Section'}</span>
        </button>
      </div>
    </form>
  );
};

// ---------------------------------------------------------------------------
// 3. WHY CHOOSE US SECTION EDITOR
// ---------------------------------------------------------------------------
const WhyUsSectionEditor: React.FC<{ onNotify: (msg: string) => void }> = ({ onNotify }) => {
  const { content, updateContent, resetToDefault, isSaving } = useSectionContent<WhyUsContent>('why_us', defaultWhyUsContent);
  const [formData, setFormData] = useState<WhyUsContent>(content);

  React.useEffect(() => {
    setFormData(content);
  }, [content]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateContent(formData);
    onNotify('Why Choose Us section updated successfully!');
  };

  const handleReset = async () => {
    if (confirm('Reset Why Choose Us to default?')) {
      await resetToDefault();
      setFormData(defaultWhyUsContent);
      onNotify('Why Choose Us reset to original default.');
    }
  };

  const updateItem = (idx: number, key: 'title' | 'description' | 'metric', val: any) => {
    const next = [...formData.items];
    next[idx] = { ...next[idx], [key]: key === 'metric' ? Number(val) : val };
    setFormData({ ...formData, items: next });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="flex items-center justify-between border-b border-gold/20 pb-3">
        <div>
          <h3 className="text-base font-heading font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <ShieldCheck size={16} className="text-gold" />
            Why Choose Us Section
          </h3>
          <p className="text-xs text-gray-400">Guarantees, quality metrics, and value proposition cards</p>
        </div>
        <button
          type="button"
          onClick={handleReset}
          className="text-xs font-mono text-gray-400 hover:text-gold flex items-center gap-1 cursor-pointer"
        >
          <RotateCcw size={13} /> Reset Default
        </button>
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-[11px] uppercase tracking-wider text-gold font-semibold mb-1">
            Section Subtitle
          </label>
          <input
            type="text"
            value={formData.subtitle}
            onChange={(e) => setFormData({ ...formData, subtitle: e.target.value })}
            placeholder="Our Guarantee"
            className="w-full bg-black-rich border border-gold/40 focus:border-gold px-3.5 py-2.5 text-xs text-white focus:outline-none"
            required
          />
        </div>
        <div>
          <label className="block text-[11px] uppercase tracking-wider text-gray-300 font-semibold mb-1">
            Section Title
          </label>
          <input
            type="text"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            placeholder="WHY CHOOSE US?"
            className="w-full bg-black-rich border border-white/20 focus:border-gold px-3.5 py-2.5 text-xs text-white focus:outline-none"
            required
          />
        </div>
      </div>

      <ImageUploadField
        label="Section Background Texture / Photograph"
        helper="Subtle architectural backdrop displayed with dark gradient overlays."
        value={formData.backgroundImage}
        onChange={(val) => setFormData({ ...formData, backgroundImage: val })}
      />

      {/* The 5 Value Cards */}
      <div className="space-y-3 pt-2 border-t border-white/10">
        <label className="block text-xs uppercase tracking-wider text-gray-200 font-semibold">
          The 5 Value Cards & Metrics
        </label>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {formData.items.map((item, idx) => (
            <div key={idx} className="bg-black-rich border border-white/10 p-3.5 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono text-gold uppercase">Card #{idx + 1}</span>
                <div className="flex items-center gap-1">
                  <span className="text-[10px] font-mono text-gray-400">Metric %:</span>
                  <input
                    type="number"
                    min="1"
                    max="100"
                    value={item.metric}
                    onChange={(e) => updateItem(idx, 'metric', e.target.value)}
                    className="w-14 bg-black-pure border border-gold/40 text-gold text-xs px-1.5 py-0.5 text-center font-mono font-bold"
                  />
                </div>
              </div>
              <input
                type="text"
                value={item.title}
                onChange={(e) => updateItem(idx, 'title', e.target.value)}
                placeholder="Title e.g. High Quality Materials"
                className="w-full bg-black-pure border border-white/20 focus:border-gold px-3 py-2 text-xs text-white focus:outline-none font-semibold"
                required
              />
              <textarea
                rows={3}
                value={item.description}
                onChange={(e) => updateItem(idx, 'description', e.target.value)}
                placeholder="Detailed explanation of the commitment..."
                className="w-full bg-black-pure border border-white/20 focus:border-gold p-2.5 text-[11px] text-gray-300 focus:outline-none resize-none"
                required
              />
            </div>
          ))}
        </div>
      </div>

      <div className="pt-4 border-t border-gold/20 flex justify-end gap-3">
        <button
          type="submit"
          disabled={isSaving}
          className="px-6 py-3 bg-gradient-to-r from-gold-dark via-gold to-gold-light hover:brightness-110 text-black-pure font-bold transition-all text-xs uppercase tracking-widest flex items-center gap-2 shadow-[0_2px_15px_rgba(212,175,55,0.35)] cursor-pointer active:scale-95 disabled:opacity-50"
        >
          <Save size={15} />
          <span>{isSaving ? 'Saving...' : 'Save Why Choose Us'}</span>
        </button>
      </div>
    </form>
  );
};

// ---------------------------------------------------------------------------
// 4. PROCESS SECTION EDITOR
// ---------------------------------------------------------------------------
const ProcessSectionEditor: React.FC<{ onNotify: (msg: string) => void }> = ({ onNotify }) => {
  const { content, updateContent, resetToDefault, isSaving } = useSectionContent<ProcessContent>('process', defaultProcessContent);
  const [formData, setFormData] = useState<ProcessContent>(content);

  React.useEffect(() => {
    setFormData(content);
  }, [content]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateContent(formData);
    onNotify('The Natal Process steps updated successfully!');
  };

  const handleReset = async () => {
    if (confirm('Reset Process steps to default?')) {
      await resetToDefault();
      setFormData(defaultProcessContent);
      onNotify('Process steps reset to original default.');
    }
  };

  const updateStep = (idx: number, key: 'title' | 'desc', val: string) => {
    const next = [...formData.steps];
    next[idx] = { ...next[idx], [key]: val };
    setFormData({ ...formData, steps: next });
  };

  const updateDeliverable = (stepIdx: number, delIdx: number, val: string) => {
    const next = [...formData.steps];
    const dels = [...(next[stepIdx].deliverables || [])];
    dels[delIdx] = val;
    next[stepIdx] = { ...next[stepIdx], deliverables: dels };
    setFormData({ ...formData, steps: next });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="flex items-center justify-between border-b border-gold/20 pb-3">
        <div>
          <h3 className="text-base font-heading font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Layers size={16} className="text-gold" />
            The Natal Process Steps
          </h3>
          <p className="text-xs text-gray-400">Step-by-step project delivery roadmap and client deliverables</p>
        </div>
        <button
          type="button"
          onClick={handleReset}
          className="text-xs font-mono text-gray-400 hover:text-gold flex items-center gap-1 cursor-pointer"
        >
          <RotateCcw size={13} /> Reset Default
        </button>
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-[11px] uppercase tracking-wider text-gold font-semibold mb-1">
            Section Eyebrow
          </label>
          <input
            type="text"
            value={formData.subtitle}
            onChange={(e) => setFormData({ ...formData, subtitle: e.target.value })}
            placeholder="Structured Execution"
            className="w-full bg-black-rich border border-gold/40 focus:border-gold px-3.5 py-2.5 text-xs text-white focus:outline-none"
            required
          />
        </div>
        <div>
          <label className="block text-[11px] uppercase tracking-wider text-gray-300 font-semibold mb-1">
            Section Title
          </label>
          <input
            type="text"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            placeholder="The Natal Process"
            className="w-full bg-black-rich border border-white/20 focus:border-gold px-3.5 py-2.5 text-xs text-white focus:outline-none"
            required
          />
        </div>
      </div>

      <div className="space-y-4 pt-2 border-t border-white/10">
        <label className="block text-xs uppercase tracking-wider text-gray-200 font-semibold">
          5 Process Stages
        </label>
        {formData.steps.map((step, idx) => (
          <div key={idx} className="bg-black-rich border border-white/10 p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-white/5 pb-2">
              <span className="text-xs font-mono text-gold font-bold uppercase">
                Step 0{idx + 1}
              </span>
            </div>
            <div className="grid sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[10px] uppercase text-gray-400 font-mono mb-1">
                  Step Title
                </label>
                <input
                  type="text"
                  value={step.title}
                  onChange={(e) => updateStep(idx, 'title', e.target.value)}
                  placeholder="e.g. Discovery & Consultation"
                  className="w-full bg-black-pure border border-white/20 focus:border-gold px-3 py-2 text-xs text-white focus:outline-none"
                  required
                />
              </div>
              <div>
                <label className="block text-[10px] uppercase text-gray-400 font-mono mb-1">
                  Step Description
                </label>
                <textarea
                  rows={2}
                  value={step.desc}
                  onChange={(e) => updateStep(idx, 'desc', e.target.value)}
                  placeholder="Brief explanation of this phase..."
                  className="w-full bg-black-pure border border-white/20 focus:border-gold p-2.5 text-xs text-gray-300 focus:outline-none resize-none"
                  required
                />
              </div>
            </div>

            {/* Deliverables tags */}
            <div>
              <span className="text-[10px] font-mono uppercase text-gray-400 block mb-1.5">
                Key Deliverables (3 items)
              </span>
              <div className="grid sm:grid-cols-3 gap-2">
                {[0, 1, 2].map((delIdx) => (
                  <input
                    key={delIdx}
                    type="text"
                    value={step.deliverables?.[delIdx] || ''}
                    onChange={(e) => updateDeliverable(idx, delIdx, e.target.value)}
                    placeholder={`Deliverable #${delIdx + 1}`}
                    className="w-full bg-black-pure border border-white/10 focus:border-gold px-2.5 py-1.5 text-[11px] text-gray-300 focus:outline-none"
                  />
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="pt-4 border-t border-gold/20 flex justify-end gap-3">
        <button
          type="submit"
          disabled={isSaving}
          className="px-6 py-3 bg-gradient-to-r from-gold-dark via-gold to-gold-light hover:brightness-110 text-black-pure font-bold transition-all text-xs uppercase tracking-widest flex items-center gap-2 shadow-[0_2px_15px_rgba(212,175,55,0.35)] cursor-pointer active:scale-95 disabled:opacity-50"
        >
          <Save size={15} />
          <span>{isSaving ? 'Saving...' : 'Save Process Steps'}</span>
        </button>
      </div>
    </form>
  );
};

// ---------------------------------------------------------------------------
// 5. STATS SECTION EDITOR
// ---------------------------------------------------------------------------
const StatsSectionEditor: React.FC<{ onNotify: (msg: string) => void }> = ({ onNotify }) => {
  const { content, updateContent, resetToDefault, isSaving } = useSectionContent<StatsContent>('stats', defaultStatsContent);
  const [formData, setFormData] = useState<StatsContent>(content);

  React.useEffect(() => {
    setFormData(content);
  }, [content]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateContent(formData);
    onNotify('Statistics counters updated successfully!');
  };

  const handleReset = async () => {
    if (confirm('Reset Stats to default?')) {
      await resetToDefault();
      setFormData(defaultStatsContent);
      onNotify('Stats reset to original default.');
    }
  };

  const updateStat = (idx: number, key: 'label' | 'value' | 'suffix', val: any) => {
    const next = [...formData.stats];
    next[idx] = { ...next[idx], [key]: key === 'value' ? Number(val) : val };
    setFormData({ ...formData, stats: next });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="flex items-center justify-between border-b border-gold/20 pb-3">
        <div>
          <h3 className="text-base font-heading font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Clock size={16} className="text-gold" />
            Milestones & Statistics
          </h3>
          <p className="text-xs text-gray-400">Animated number counters displayed across the website</p>
        </div>
        <button
          type="button"
          onClick={handleReset}
          className="text-xs font-mono text-gray-400 hover:text-gold flex items-center gap-1 cursor-pointer"
        >
          <RotateCcw size={13} /> Reset Default
        </button>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {formData.stats.map((stat, idx) => (
          <div key={idx} className="bg-black-rich border border-white/10 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono text-gold uppercase">Counter #{idx + 1}</span>
            </div>
            <div>
              <label className="block text-[10px] uppercase text-gray-400 font-mono mb-1">
                Display Label
              </label>
              <input
                type="text"
                value={stat.label}
                onChange={(e) => updateStat(idx, 'label', e.target.value)}
                placeholder="Projects Completed"
                className="w-full bg-black-pure border border-white/20 focus:border-gold px-3 py-2 text-xs text-white focus:outline-none"
                required
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[10px] uppercase text-gray-400 font-mono mb-1">
                  Target Value
                </label>
                <input
                  type="number"
                  value={stat.value}
                  onChange={(e) => updateStat(idx, 'value', e.target.value)}
                  placeholder="350"
                  className="w-full bg-black-pure border border-gold/40 text-gold font-mono font-bold px-3 py-2 text-xs focus:outline-none"
                  required
                />
              </div>
              <div>
                <label className="block text-[10px] uppercase text-gray-400 font-mono mb-1">
                  Suffix
                </label>
                <input
                  type="text"
                  value={stat.suffix}
                  onChange={(e) => updateStat(idx, 'suffix', e.target.value)}
                  placeholder="+"
                  className="w-full bg-black-pure border border-white/20 focus:border-gold px-3 py-2 text-xs text-white focus:outline-none font-mono"
                  required
                />
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="pt-4 border-t border-gold/20 flex justify-end gap-3">
        <button
          type="submit"
          disabled={isSaving}
          className="px-6 py-3 bg-gradient-to-r from-gold-dark via-gold to-gold-light hover:brightness-110 text-black-pure font-bold transition-all text-xs uppercase tracking-widest flex items-center gap-2 shadow-[0_2px_15px_rgba(212,175,55,0.35)] cursor-pointer active:scale-95 disabled:opacity-50"
        >
          <Save size={15} />
          <span>{isSaving ? 'Saving...' : 'Save Statistics'}</span>
        </button>
      </div>
    </form>
  );
};

// ---------------------------------------------------------------------------
// 6. CONTACT & STUDIO INFO EDITOR
// ---------------------------------------------------------------------------
const ContactSectionEditor: React.FC<{ onNotify: (msg: string) => void }> = ({ onNotify }) => {
  const { content, updateContent, resetToDefault, isSaving } = useSectionContent<ContactContent>('contact', defaultContactContent);
  const [formData, setFormData] = useState<ContactContent>(content);

  React.useEffect(() => {
    setFormData(content);
  }, [content]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateContent(formData);
    onNotify('Company details & contact info updated successfully!');
  };

  const handleReset = async () => {
    if (confirm('Reset Contact Details to default?')) {
      await resetToDefault();
      setFormData(defaultContactContent);
      onNotify('Contact Details reset to original default.');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="flex items-center justify-between border-b border-gold/20 pb-3">
        <div>
          <h3 className="text-base font-heading font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <MapPin size={16} className="text-gold" />
            Studio Information & Contact Channels
          </h3>
          <p className="text-xs text-gray-400">Atelier address, official phone lines, WhatsApp numbers, email, and social networks</p>
        </div>
        <button
          type="button"
          onClick={handleReset}
          className="text-xs font-mono text-gray-400 hover:text-gold flex items-center gap-1 cursor-pointer"
        >
          <RotateCcw size={13} /> Reset Default
        </button>
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-[11px] uppercase tracking-wider text-gray-300 font-semibold mb-1">
            Company Full Legal / Atelier Name
          </label>
          <input
            type="text"
            value={formData.companyName}
            onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
            placeholder="NATAL INTERIOR DESIGN CONSTRUCTION"
            className="w-full bg-black-rich border border-white/20 focus:border-gold px-3.5 py-2.5 text-xs text-white focus:outline-none"
            required
          />
        </div>
        <div>
          <label className="block text-[11px] uppercase tracking-wider text-gray-300 font-semibold mb-1">
            Atelier Physical Location
          </label>
          <input
            type="text"
            value={formData.location}
            onChange={(e) => setFormData({ ...formData, location: e.target.value })}
            placeholder="Mawanda Road Mulago3"
            className="w-full bg-black-rich border border-white/20 focus:border-gold px-3.5 py-2.5 text-xs text-white focus:outline-none"
            required
          />
        </div>
      </div>

      {/* Official Email */}
      <div>
        <label className="block text-[11px] uppercase tracking-wider text-gray-300 font-semibold mb-1">
          Official Email Address
        </label>
        <input
          type="email"
          value={formData.email}
          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
          placeholder="usherhenry99@gmail.com"
          className="w-full bg-black-rich border border-white/20 focus:border-gold px-3.5 py-2.5 text-xs text-white focus:outline-none font-mono"
          required
        />
      </div>

      {/* Phone Numbers & WhatsApp */}
      <div className="grid sm:grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="block text-[11px] uppercase tracking-wider text-gray-300 font-semibold">
            Phone Numbers (Calls)
          </label>
          <input
            type="text"
            value={formData.phoneNumbers[0] || ''}
            onChange={(e) => {
              const next = [...formData.phoneNumbers];
              next[0] = e.target.value;
              setFormData({ ...formData, phoneNumbers: next });
            }}
            placeholder="Primary Phone: 0755 519 830"
            className="w-full bg-black-rich border border-white/20 focus:border-gold px-3 py-2 text-xs text-white focus:outline-none font-mono"
          />
          <input
            type="text"
            value={formData.phoneNumbers[1] || ''}
            onChange={(e) => {
              const next = [...formData.phoneNumbers];
              next[1] = e.target.value;
              setFormData({ ...formData, phoneNumbers: next });
            }}
            placeholder="Secondary Phone: 0745 694 499"
            className="w-full bg-black-rich border border-white/20 focus:border-gold px-3 py-2 text-xs text-white focus:outline-none font-mono"
          />
        </div>

        <div className="space-y-2">
          <label className="block text-[11px] uppercase tracking-wider text-gold font-semibold">
            WhatsApp Numbers (Chat)
          </label>
          <input
            type="text"
            value={formData.whatsappNumbers[0] || ''}
            onChange={(e) => {
              const next = [...formData.whatsappNumbers];
              next[0] = e.target.value;
              setFormData({ ...formData, whatsappNumbers: next });
            }}
            placeholder="Primary WhatsApp: 0745 694 499"
            className="w-full bg-black-rich border border-gold/40 focus:border-gold px-3 py-2 text-xs text-white focus:outline-none font-mono"
          />
          <input
            type="text"
            value={formData.whatsappNumbers[1] || ''}
            onChange={(e) => {
              const next = [...formData.whatsappNumbers];
              next[1] = e.target.value;
              setFormData({ ...formData, whatsappNumbers: next });
            }}
            placeholder="Secondary WhatsApp (Optional)"
            className="w-full bg-black-rich border border-gold/40 focus:border-gold px-3 py-2 text-xs text-white focus:outline-none font-mono"
          />
        </div>
      </div>

      {/* Social Media Links */}
      <div className="space-y-3 pt-2 border-t border-white/10">
        <label className="block text-xs uppercase tracking-wider text-gray-200 font-semibold">
          Social Media Platforms
        </label>
        <div className="grid sm:grid-cols-3 gap-3">
          <div>
            <span className="text-[10px] font-mono text-gray-400 block mb-1">TikTok Profile URL</span>
            <input
              type="url"
              value={formData.tiktokUrl}
              onChange={(e) => setFormData({ ...formData, tiktokUrl: e.target.value })}
              placeholder="https://www.tiktok.com/@natalinteriors"
              className="w-full bg-black-rich border border-white/20 focus:border-gold px-3 py-2 text-xs text-white focus:outline-none font-mono"
            />
          </div>
          <div>
            <span className="text-[10px] font-mono text-gray-400 block mb-1">Facebook Page URL</span>
            <input
              type="url"
              value={formData.facebookUrl}
              onChange={(e) => setFormData({ ...formData, facebookUrl: e.target.value })}
              placeholder="https://www.facebook.com/natalinteriordesign"
              className="w-full bg-black-rich border border-white/20 focus:border-gold px-3 py-2 text-xs text-white focus:outline-none font-mono"
            />
          </div>
          <div>
            <span className="text-[10px] font-mono text-gray-400 block mb-1">LinkedIn Page URL</span>
            <input
              type="url"
              value={formData.linkedinUrl}
              onChange={(e) => setFormData({ ...formData, linkedinUrl: e.target.value })}
              placeholder="https://www.linkedin.com/company/natal-interior-design-construction"
              className="w-full bg-black-rich border border-white/20 focus:border-gold px-3 py-2 text-xs text-white focus:outline-none font-mono"
            />
          </div>
        </div>
      </div>

      <div className="pt-4 border-t border-gold/20 flex justify-end gap-3">
        <button
          type="submit"
          disabled={isSaving}
          className="px-6 py-3 bg-gradient-to-r from-gold-dark via-gold to-gold-light hover:brightness-110 text-black-pure font-bold transition-all text-xs uppercase tracking-widest flex items-center gap-2 shadow-[0_2px_15px_rgba(212,175,55,0.35)] cursor-pointer active:scale-95 disabled:opacity-50"
        >
          <Save size={15} />
          <span>{isSaving ? 'Saving...' : 'Save Studio & Contact Info'}</span>
        </button>
      </div>
    </form>
  );
};

export default SiteSectionsEditor;
