import React from 'react';

export default function NatalLogo({ 
  className = "h-12",
  variant = "default"
}: { 
  className?: string;
  variant?: "default" | "small"
}) {
  const isSmall = variant === "small";

  return (
    <div className={`flex flex-col justify-center text-left ${className}`}>
      <p className={`font-heading font-bold tracking-[0.15em] text-white leading-none uppercase ${
        isSmall 
          ? "text-[10px] sm:text-xs md:text-sm" 
          : "text-sm sm:text-base lg:text-3xl"
      }`}>
        Natal Interior
      </p>
      <p className={`tracking-[0.15em] text-gold uppercase font-medium ${
        isSmall 
          ? "text-[7px] sm:text-[8px] md:text-[9px] mt-0.5" 
          : "text-[7px] sm:text-[8px] lg:text-sm mt-1"
      }`}>
        Design Construction
      </p>
    </div>
  );
}
